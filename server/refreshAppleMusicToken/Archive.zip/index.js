const AWS = require('aws-sdk');
import * as jwt from 'jsonwebtoken';

//////  REFRESH TOKEN
//  Generates & sets an Apple Music API access token good for 1 hour (3600s).
//  https://developer.apple.com/documentation/applemusicapi/getting_keys_and_creating_tokens
//////
exports.handler = event => {
  const teamID = process.env.TEAM_ID;
  const keyID = process.env.KEY_ID;

  const privateKey = fs.readFileSync('MusicKitKey.p8');

  const token = jwt.sign({}, privateKey, {
    algorithm: 'ES256',
    expiresIn: '1h',
    issuer: teamID,
    keyid: keyID,
  });

  return 'Success';
};
